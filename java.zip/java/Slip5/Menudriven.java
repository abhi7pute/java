package assigment1;
import java.util.Scanner;
public class matrix {

	public static void main(String[] args) {
		int ch=0,q=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of array");
		int n=sc.nextInt();
		int a[][]=new int[n][n];
		int b[][]=new int[n][n];
	    int c[][]=new int[n][n];
        System.out.println("Enter the element of array A");
        for(int i=0;i<n;i++)
        {for(int j=0;j<n;j++)
        {a[i][j]=sc.nextInt();
        }
        }
        System.out.println("the element of array A");
        for(int i=0;i<n;i++)
        {for(int j=0;j<n;j++)
        {System.out.println(""+a[i][j]);
        }
    	}
        System.out.println("Enter the element of array B");
        for(int i1=0;i1<n;i1++)
        {for(int j=0;j<n;j++)
        {b[i1][j]=sc.nextInt();
        }
	    }
        System.out.println("the element of array B");
        for(int i1=0;i1<n;i1++)
        {for(int j=0;j<n;j++)
        {System.out.println(""+b[i1][j]);
        }
        }
        do
       {
    	   System.out.println("1.Addition:");
    	   System.out.println("2.Multiplication:");
    	   System.out.println("3.Transpose of any matrix:");
    	   System.out.println("4.Exit:");
    	   System.out.println("Enter your choice:");
    	   ch=sc.nextInt();
    	
       switch(ch) {
       case 1:
       {System.out.println("Addition of A and B");
       for(int i1=0;i1<n;i1++)
       {for(int j=0;j<n;j++)
       {c[i1][j]=a[i1][j]+b[i1][j];
       }
       }
       System.out.println("Addition is");
       for(int i1=0;i1<n;i1++)
       {for(int j=0;j<n;j++)	   
       System.out.println(" "+c[i1][j]);
       }
       }
       break;
       case 2:
       {System.out.println("Muliplecation of A and B");
       for(int i1=0;i1<n;i1++)
       {for(int j=0;j<n;j++)
       {c[i1][j]=a[i1][j]*b[i1][j];
       }
       }
       System.out.println("Muliplecation is");
       for(int i11=0;i11<n;i11++)
       {for (int j=0;j<n;j++)	
       {
       System.out.println(" "+c[i11][j]);
       }
       }
       }
       break;  
       case 3:
       {System.out.println("Transpose of A");
       for(int i1=0;i1<n;i1++)
       {for(int j=0;j<n;j++)
       {System.out.println(" "+a[j][i1]);   
       }
       System.out.println("");       
       }
       }
       break;
       case 4:
       {q=1;
       }
       break;
       }
       }while(q==0);
       }
       }
       
      




	


