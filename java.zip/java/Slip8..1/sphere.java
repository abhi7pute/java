package avinashmalawade;
public class sphere { 
	    public static void main(String args[])  
	    {  
	  
	    int radius=37;  
	   double pie=3.14285714286;  
	   double area_sphere=4*pie*(radius*radius);  
	        System.out.println("Surface area of sphere="+area_sphere);  
	     }  
	}  
	