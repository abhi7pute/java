
import java.util.*;
import java.util.Scanner;
interface ProductMarker
{
	
	
}
class product implements ProductMarker
{
	int pid;
	String pname;
	double pcost;
	int pqty;
	static int cnt=0;
	
	product()
	{}
	product(int pid,String pname,double pcost,int pqty)
	{
		this.pid=pid;
		this.pname=pname;
		this.pcost=pcost;
		this.pqty=pqty;
		cnt++;
	}
	void display()
	{
		System.out.println(pid+"     "+pname+"         "+pcost+"          "+pqty);
	}
	static void count()
	{
		System.out.println("Total number of objects created:"+cnt);
	}
}
public class ass3B2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter how many products");
		int n=sc.nextInt();
		
		product p[]=new product[n];
		for(int i=0;i<n;i++)
		{
		System.out.println("enter product id");
		int id=sc.nextInt();
		System.out.println("enter product name");
		String name=sc.next();
		System.out.println("enter product cost");
		double cost=sc.nextDouble();
		System.out.println("enter product quantity");
		int qty=sc.nextInt();
		p[i]=new product(id,name,cost,qty);
	
		}
		if(p[0] instanceof ProductMarker)
	{
			System.out.println("Product Details are");
			System.out.println("ProductID"+"   "+"ProductName"+"  "+"ProductCost"+"   "+"ProductQuantity");
			for(int i=0;i<n;i++)
			{
				
			p[i].display();
			
				
			}
	}
		product.count();
		
			
		
		// TODO Auto-generated method stub

	}

}
