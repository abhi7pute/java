package avinashmalawade;
import java.util.Scanner;
class patient 
{
   String name;
   int age;
   int oxylevel;
   int HRCTreport;
   patient(String name,int age,int oxylevel,int HRCTreport)
   {
   this.name=name;
   this.age=age;
   this.oxylevel=oxylevel;
   this.HRCTreport=HRCTreport;
   }
}
public class assigmentno4A1 extends Exception
{
   public static void main(String args[])
   {
     Scanner sc=new Scanner(System.in);
     System.out.println("How many Patient");
     int n=sc.nextInt();
     patient p[]=new patient[n];
     for(int i=0;i<n;i++)
     {
       System.out.println("Enter Patient name");
       String name=sc.next();
       System.out.println("Enter Patient Age");
       int age=sc.nextInt();
       System.out.println("Enter Patient oxygen level");
       int oxylevel=sc.nextInt();
       System.out.println("Enter Patient HRCT Reportor Score");
       int HRCTreport=sc.nextInt();
       p[i]=new patient(name,age,oxylevel,HRCTreport);
     }
     for(int i=0;i<n;i++)
     {
        if(p[i].oxylevel<95 && p[i].HRCTreport>10)
        {
           try
           {
             throw new NullPointerException("Patient is Covid Positive");
           }
           catch(Exception e)
           {
             System.out.println("Patient is covid positive and need to hospitalized");
           }
         }
         else
         {
           System.out.println("Patient Name:"+p[i].name);
           System.out.println("Patient Age:"+p[i].age);
           System.out.println("Patient oxygen level :"+p[i].oxylevel);
          System.out.println("Patient HRCT Reportor Score:"+p[i].HRCTreport);
         }
       }
     }
  }
             
