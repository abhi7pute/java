import java.util.Scanner;
public class primenumbers
{
public static void main (String[] args)
{
int[] array = new int [5];
Scanner in = new Scanner (System.in);
System.out.println("Enter the elements of the array: ");
for(int i=0; i<5; i++)
{
array[i] = in.nextInt();
}
}
}
