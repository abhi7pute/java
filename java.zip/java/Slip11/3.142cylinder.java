package avinashmalawade;
import java.util.Scanner;
interface Operation
	{
	   double area();
	   double volume();
	   double PI=3.142;
	}
	class Cylinder implements Operation
	{
	   float r,h;
	   public void Accept()
	   {
	     Scanner sc=new Scanner(System.in);
	     System.out.println("Enter radius and height for calculating area of cylinder ");
	     r=sc.nextFloat();
	     h=sc.nextFloat();
	   }
	   public double area()
	   {
	     double area=(2*PI*(r*h));
	     return area;
	   }
	   public double volume()
	   {
	     double volm=(PI*r*r*h);
	     return volm;
	   }
	   
	}
	class assigmentno3A3
	{
	    public static void main(String args[])
	    {
	       Cylinder cl=new Cylinder();
	       cl.Accept();
	       System.out.println("Area of Cylinder :"+cl.area());
	       System.out.println("Volume of Cylinder :"+cl.volume());
	    }
	}



