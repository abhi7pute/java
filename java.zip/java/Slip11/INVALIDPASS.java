package avinashmalawade;
class EmailId 
{
	String username="avi";
	String password="deep123";
	public EmailId()
	{
	 
	}
	public EmailId(String user,String pass)
	{
	username=user;
	password=pass;
	}
	}
class InvalidUsernameException extends Exception
{
String num1;
InvalidUsernameException(String num2)
 {
num1=num2;
 }
public String toString()
{
return ("exception in thread ‘main’ InvalidUsernameException: Username: "+ num1 + " doesn’t match");
}
}
class InvalidPasswordException extends Exception
{
String num1;
InvalidPasswordException(String num2)
 {
num1=num2;
}
public String toString()
{
return ("exception in thread ‘main’ InvalidPasswordException: Password: "+ num1 + " doesn’t match");
}
}
public class assigmentno4B2 {

	public static void main(String[] args) {
		String user=args[0];
		String pass=args[1];
		int up=-1,u=-1;
		EmailId obj=new EmailId();
		EmailId obj1=new EmailId(user,pass);
		if((obj.username).equals(obj1.username))
		{
		u=1;
		}
		else
		{
		u=0;
		}
		if(obj.password.equals(obj1.password))
		{
		up=1;
		}
		else
		{
		up=0;
		}


		if(u==0)
		{
		try
		{
		throw new InvalidUsernameException(user);
		}
		catch (Exception e) 
		{
		System.out.println(e) ;
		}
		}
		if (up==0)
		{
		try
		{
		throw new InvalidPasswordException(pass);
		}
		catch (Exception e) 
		{
		System.out.println(e) ;
		}
		}

		if(u==1 && up==1)
		{

		System.out.println("Valid emailid and password");
		}
		
		
	

	}

}
