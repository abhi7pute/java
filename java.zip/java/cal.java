
import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import java.awt.event.ActionEvent;
public class cal extends JFrame implements ActionListener
	{
  int x;
  double n;
	   String s1,s2,s3,s4,s5,s6;
		JPanel jp=new JPanel();
		JFrame f=new JFrame();
		JTextField jt;
		JButton b0,b1,b2,b3,b4,b5,b6,b7,b8,b9,ba,bs,bm,bd,bdot,be,bc;
	cal()
		{	
		f.setTitle("Simple Calculator");
		f.setLayout(new FlowLayout());		
		b1=new JButton("1");
		 b1.addActionListener(this);
		b2=new JButton("2");
		b2.addActionListener(this);
		b3=new JButton("3");
		b3.addActionListener(this);
		ba=new JButton("+");
		ba.addActionListener(this);
		b4=new JButton("4");
		b4.addActionListener(this);
		b5=new JButton("5");
		b5.addActionListener(this);
		b6=new JButton("6");
		b6.addActionListener(this);
		bs=new JButton("-");
		bs.addActionListener(this);
		b7=new JButton("7");
		b7.addActionListener(this);
		b8=new JButton("8");
		b8.addActionListener(this);
		b9=new JButton("9");
		b9.addActionListener(this);
		bm=new JButton("*");
	
		bm.addActionListener(this);
		b0=new JButton("0");
	
		b0.addActionListener(this);
		bdot=new JButton(".");
	
		bdot.addActionListener(this);
		be=new JButton("=");
		
		be.addActionListener(this);
		bd=new JButton("/");
	
		bd.addActionListener(this);
		bc=new JButton("Clear");
		bc.addActionListener(this);
		 jt=new JTextField(20);
		f.add(jt);
     GridLayout g=new GridLayout(5,4,10,10);
		
		jp.setLayout(g);
		jp.add(b1);jp.add(b2);jp.add(b3);jp.add(ba);	jp.add(b4);jp.add(b5);jp.add(b6);jp.add(bs);jp.add(b7);
		jp.add(b8);	jp.add(b9);	jp.add(bm);	jp.add(b0);	jp.add(bdot);jp.add(be);	jp.add(bd);jp.add(bc);
		f.add(jp);
		f.setSize(400,300);
		f.setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		}
	public void actionPerformed(ActionEvent e)
    {
		if(e.getSource()==bc)
		{
			jt.setText("");
		}
		if(e.getSource()==bdot)
        {
        	s3=jt.getText();
        	s6="0";
        	s5=s3+s6;
        	
        	jt.setText(s5);
        }
        if(e.getSource()==b0)
        {
        	s3=jt.getText();
            s4 = "";
            s5 = s3+s4;
          jt.setText(s5);
        }
        
            if(e.getSource()==b1)
            {
            	
                s3 = jt.getText();
                s4 = "1";
                s5 = s3+s4;
               jt.setText(s5);
            }
            
                    if(e.getSource()==b2)
                    {
                    	
                        s3 = jt.getText();
                        s4 = "2";
                        s5 = s3+s4;
                        jt.setText(s5);
                    }
                    
                    if(e.getSource()==b3)
                    {
                    	
                        s3 = jt.getText();
                        s4 = "3";
                        s5 = s3+s4;
                       jt.setText(s5);
                    }
                    
                    if(e.getSource()==b4)
                    {                	
                        s3 =jt.getText();
                        s4 = "4";
                        s5 = s3+s4;
                        jt.setText(s5);
                    }
                    
                    if(e.getSource()==b5)
                    {
                    	
                        s3 = jt.getText();
                        s4 = "5";
                        s5 = s3+s4;
                        jt.setText(s5);
                    }
                    if(e.getSource()==b6)
                    {
                    	s3=jt.getText();
                    	
                        s4 = "6";
                        s5 = s3+s4;
                        jt.setText(s5);
                    }
                    
                    if(e.getSource()==b7)
                    {
                    	
                        s3 =jt.getText();
                        s4 = "7";
                        s5 = s3+s4;
                        jt.setText(s5);
                    }
                    
                    if(e.getSource()==b8)
                    {
                    	
                        s3 = jt.getText();
                        s4 = "8";
                        s5 = s3+s4;
                       jt.setText(s5);
                    }
                 
                    if(e.getSource()==b9)
                    { 
                    	
                        s3 = jt.getText();
                        s4 = "9";
                        s5 = s3+s4;
                       jt.setText(s5);
                    }           
                    if(e.getSource()==ba)
                    {
                        s1 =jt.getText();
                        jt.setText("");
                        x=1;
             
                    }
                    if(e.getSource()==bs)
                    {
                        s1 = jt.getText();
                        jt.setText("");
                        x=2;
                    }
                    if(e.getSource()==bm)
                    {
                        s1 = jt.getText();
                        jt.setText("");
                        x=3;
             
                    }
                    if(e.getSource()==bd)
                    {
                        s1 = jt.getText();
                        jt.setText("");
                        x=4;
             
                    }
                                         
                       
                    if(e.getSource()==be)
                    {
                        s2 = jt.getText();
                        if(x==1)
                        {
                            n = Double.parseDouble(s1)+Double.parseDouble(s2);
                        jt.setText(String.valueOf(n));
                        }    
                        else
                        if(x==2)
                        {
                        	  n = Double.parseDouble(s1)-Double.parseDouble(s2);
                            jt.setText(String.valueOf(n));
                        }
                        else
                        if(x==3)
                        {
                        	  n = Double.parseDouble(s1)*Double.parseDouble(s2);
                            jt.setText(String.valueOf(n));
                        }
                        if(x==4)
                        {
                            try
                            {
                                int p=Integer.parseInt(s2);
                                if(p!=0)
                                {
                                	  n = Double.parseDouble(s1)/Double.parseDouble(s2);
                               jt.setText(String.valueOf(n));
                                 }
                                 else
                                    jt.setText("infinite");
             
                            }
                            catch(Exception i){}
                        }
                        
                       
                    }
            }
	public static void main(String[] args) {
		cal c=new cal(); 

	}

}