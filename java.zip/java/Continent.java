package rohitkale;
import java.io.*;
class Continent
{
	String ConName;
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	void getName() throws IOException
	{
      System.out.println("Enter the continent name");
      ConName=br.readLine();
    }
}
class Country extends Continent
{
	String Country_name;
	void Accept() throws IOException
	{
	 System.out.println("Enter the country name");
	 Country_name=br.readLine();
	}
}
class State extends Country
{
	String State_name;
	String Place_name;
	void get() throws IOException
	{
		System.out.println("Enter the State and place name");
	    State_name=br.readLine();
	    Place_name=br.readLine();
	}

	public static void main(String[] args) throws IOException
	{
		State st=new State();
		st.getName();
		st.Accept();
		st.get();
		System.out.println("Continent Name:"+st.ConName);
		System.out.println("Country Name:"+st.Country_name);
		System.out.println("State Name:"+st.State_name);
		System.out.println("Place Name:"+st.Place_name);
	}

}
